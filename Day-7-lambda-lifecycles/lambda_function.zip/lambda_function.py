# Simple Python program

def add_numbers(a, b):
    return a + b

x = 10
y = 20

result = add_numbers(x, y)

print("Hello, World!")
print(f"The sum of {x} and {y} is {result}")